package com.cognizant.Movie_Cruiser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieCruiserApplicationTests {

	@Test
	void contextLoads() {
	}

}
