package com.cognizant.designPatterns;

public interface IOrder {
	void ProcessOrder(String modelName);
}
